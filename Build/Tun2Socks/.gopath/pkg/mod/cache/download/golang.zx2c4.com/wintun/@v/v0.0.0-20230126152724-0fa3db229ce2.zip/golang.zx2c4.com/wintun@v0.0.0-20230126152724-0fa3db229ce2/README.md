## wintun-go

This contains bindings to use [Wintun](https://www.wintun.net) from Go.

```go
import "golang.zx2c4.com/wintun"
```

- [Documentation](https://pkg.go.dev/golang.zx2c4.com/wintun)
