// Automatically generated marshal implementation. See tools/go_marshal.

package fpu

import (
)

