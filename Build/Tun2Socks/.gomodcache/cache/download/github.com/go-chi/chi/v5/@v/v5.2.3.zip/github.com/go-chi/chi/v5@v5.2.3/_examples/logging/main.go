package main

// Please see https://github.com/go-chi/httplog for a complete package
// and example for writing a structured logger on chi built on
// the Go 1.21+ "log/slog" package.

func main() {
	// See https://github.com/go-chi/httplog/blob/master/_example/main.go
}
