// This file includes the tools the gomobile depends on.

//go:build tools

package main

import (
	_ "golang.org/x/mobile/cmd/gobind"
)
